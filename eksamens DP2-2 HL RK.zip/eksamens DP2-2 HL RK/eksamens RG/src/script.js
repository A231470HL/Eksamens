document.addEventListener('DOMContentLoaded', function() {
  // Variables
  const addToCartButtons = document.querySelectorAll('.add-to-cart');
  const cartCountElement = document.getElementById('cart-count');
  const searchButton = document.getElementById('search-button');
  const searchInput = document.getElementById('search-input');
  const viewProductsButton = document.getElementById('view-products');
  const addProductButton = document.getElementById('add-product-btn');
  const modal = document.getElementById('add-product-modal');
  const closeButton = document.querySelector('.close');
  const addProductForm = document.getElementById('add-product-form');
  const productGrid = document.querySelector('.product-grid');
  
  // Cart functionality
  let cartCount = 0;
  
  // Add to cart button event listeners
  addToCartButtons.forEach(button => {
      button.addEventListener('click', addToCart);
  });
  
  // Function to add product to cart
  function addToCart() {
      cartCount++;
      cartCountElement.textContent = cartCount;
      cartCountElement.style.display = 'block';
      
      // Animation effect
      this.innerHTML = 'ADDED!';
      this.style.backgroundColor = '#4CAF50';
      
      setTimeout(() => {
          this.innerHTML = 'ADD TO CART';
          this.style.backgroundColor = '#ff0000';
      }, 1000);
  }
  
  // Add remove button to existing product cards
  document.querySelectorAll('.product-card').forEach(card => {
      addRemoveButton(card);
  });
  
  // Function to add remove button to product card
  function addRemoveButton(card) {
      // Check if remove button already exists
      if (!card.querySelector('.remove-product')) {
          const removeButton = document.createElement('button');
          removeButton.classList.add('remove-product');
          removeButton.innerHTML = 'REMOVE';
          removeButton.addEventListener('click', function() {
              removeProduct(card);
          });
          card.appendChild(removeButton);
      }
  }
  
  // Function to remove product
  function removeProduct(card) {
      // Add fade-out animation
      card.style.transition = 'opacity 0.5s ease-out';
      card.style.opacity = '0';
      
      // Remove card after animation completes
      setTimeout(() => {
          card.remove();
      }, 500);
  }
  
  // Search functionality
  searchButton.addEventListener('click', performSearch);
  searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
          performSearch();
      }
  });
  
  function performSearch() {
      const searchTerm = searchInput.value.toLowerCase().trim();
      
      if (searchTerm === '') {
          alert('Please enter a search term');
          return;
      }
      
      const productCards = document.querySelectorAll('.product-card');
      let foundProducts = false;
      
      productCards.forEach(card => {
          const productName = card.querySelector('h3').textContent.toLowerCase();
          
          if (productName.includes(searchTerm)) {
              card.style.display = 'block';
              card.style.border = '2px solid #ff0000';
              foundProducts = true;
              
              // Scroll to the product
              setTimeout(() => {
                  card.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }, 300);
              
              // Remove highlight after 3 seconds
              setTimeout(() => {
                  card.style.border = 'none';
              }, 3000);
          } else {
              card.style.display = 'none';
          }
      });
      
      if (!foundProducts) {
          alert('No products found matching: ' + searchTerm);
          // Show all products again
          productCards.forEach(card => {
              card.style.display = 'block';
          });
      }
      
      // Clear search input
      searchInput.value = '';
  }
  
  // Scroll to products when "VIEW PRODUCTS" button is clicked
  viewProductsButton.addEventListener('click', function() {
      const productsSection = document.getElementById('products');
      productsSection.scrollIntoView({ behavior: 'smooth' });
  });
  
  // Modal for adding new products
  addProductButton.addEventListener('click', function() {
      modal.style.display = 'block';
  });
  
  closeButton.addEventListener('click', function() {
      modal.style.display = 'none';
  });
  
  window.addEventListener('click', function(event) {
      if (event.target == modal) {
          modal.style.display = 'none';
      }
  });
  
  // Add new product form submission
  addProductForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      const productName = document.getElementById('product-name').value;
      const productPrice = document.getElementById('product-price').value;
      let productImage = document.getElementById('product-image').value;
      
      // Use default placeholder if no image URL is provided
      if (!productImage) {
          productImage = 'https://via.placeholder.com/300x300/808080/FFFFFF?text=New+Product';
      }
      
      // Create new product card
      const newProductCard = document.createElement('div');
      newProductCard.classList.add('product-card');
      
      newProductCard.innerHTML = `
          <img src="${productImage}" alt="${productName}">
          <h3>${productName}</h3>
          <p class="price">${parseFloat(productPrice).toFixed(2)}$</p>
          <button class="add-to-cart">ADD TO CART</button>
      `;
      
      // Add event listener to the new add to cart button
      const newAddToCartButton = newProductCard.querySelector('.add-to-cart');
      newAddToCartButton.addEventListener('click', addToCart);
      
      // Add remove button to the new product card
      addRemoveButton(newProductCard);
      
      // Add the new product card to the grid
      productGrid.appendChild(newProductCard);
      
      // Reset form and close modal
      addProductForm.reset();
      modal.style.display = 'none';
      
      // Scroll to the new product
      setTimeout(() => {
          newProductCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 300);
      
      // Highlight new product
      newProductCard.style.border = '2px solid #4CAF50';
      setTimeout(() => {
          newProductCard.style.border = 'none';
      }, 3000);
  });
  
  // Make navigation smooth for all anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
          e.preventDefault();
          
          const targetId = this.getAttribute('href');
          if (targetId === '#') return;
          
          const targetElement = document.querySelector(targetId);
          if (targetElement) {
              targetElement.scrollIntoView({ behavior: 'smooth' });
          }
      });
  });
  
  // Responsive menu toggle for mobile
  const createResponsiveMenu = () => {
      if (window.innerWidth <= 768) {
          const nav = document.querySelector('nav');
          const navUl = nav.querySelector('ul');
          
          if (!document.querySelector('.menu-toggle')) {
              const menuToggle = document.createElement('div');
              menuToggle.classList.add('menu-toggle');
              menuToggle.innerHTML = '☰';
              menuToggle.style.cursor = 'pointer';
              menuToggle.style.fontSize = '1.5rem';
              menuToggle.style.textAlign = 'center';
              menuToggle.style.padding = '10px';
              
              nav.insertBefore(menuToggle, navUl);
              
              // Add click event listener to toggle menu visibility
              menuToggle.addEventListener('click', function() {
                  navUl.style.display = navUl.style.display === 'block' ? 'none' : 'block';
              });
          }
      }
  };
  
  // Call the createResponsiveMenu function initially
  createResponsiveMenu();
  
  // Update responsive menu on window resize
  window.addEventListener('resize', createResponsiveMenu);
});